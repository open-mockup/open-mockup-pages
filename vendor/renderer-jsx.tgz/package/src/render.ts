import type { IRDocument, IRNode, IRContainerNode } from "@openmockup/renderer-core";

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export function renderJsx(ir: IRDocument): string {
  // If the root node is already "page", render its children directly to avoid
  // double-wrapping (<Page><Page>…</Page></Page>) when round-tripping from parser-jsx.
  const root = ir.root as IRContainerNode;
  const bodyLines =
    root.dslType === "page" && root.children !== undefined
      ? root.children.map((c) => renderNode(c, 1)).join("\n")
      : renderNode(ir.root, 1);
  return `<Page title="${ir.title}">\n${bodyLines}\n</Page>`;
}

// ---------------------------------------------------------------------------
// Node dispatch
// ---------------------------------------------------------------------------

function renderNode(n: IRNode, depth: number): string {
  return n.kind === "container"
    ? renderContainer(n as IRContainerNode, depth)
    : renderLeaf(n, depth);
}

// ---------------------------------------------------------------------------
// Containers
// ---------------------------------------------------------------------------

// dslType → PascalCase component name
const COMPONENT: Record<string, string> = {
  stack: "Stack",
  grid: "Grid",
  split: "Split",
  section: "Section",
  card: "Card",
  form: "Form",
  actionBar: "ActionBar",
  modal: "Modal",
  drawer: "Drawer",
  popover: "Popover",
  customComponent: "CustomComponent",
};

function renderContainer(n: IRContainerNode, depth: number): string {
  const tag = COMPONENT[n.dslType] ?? pascal(n.dslType);
  const attrs = propsToAttrs(n.props);
  const indent = "  ".repeat(depth);
  const childIndent = "  ".repeat(depth + 1);

  if (n.children.length === 0) {
    return `${indent}<${tag}${attrs} />`;
  }

  const childLines = n.children.map((c) => renderNode(c, depth + 1)).join("\n");
  return `${indent}<${tag}${attrs}>\n${childLines}\n${indent}</${tag}>`;
}

// ---------------------------------------------------------------------------
// Leaves
// ---------------------------------------------------------------------------

// Nodes whose primary content is rendered as JSX children (not a prop).
const TEXT_CHILD: Record<string, string> = {
  button: "label",
  linkAction: "label",
  label: "text",
  heading: "text",
  paragraph: "text",
  badge: "text",
  alert: "text",
};

function renderLeaf(n: IRNode, depth: number): string {
  const tag = pascal(n.dslType);
  const indent = "  ".repeat(depth);
  const childProp = TEXT_CHILD[n.dslType];

  if (childProp !== undefined) {
    const text = n.props[childProp] as string;
    const rest = { ...n.props };
    delete rest[childProp];
    const attrs = propsToAttrs(rest);
    return `${indent}<${tag}${attrs}>${text}</${tag}>`;
  }

  const attrs = propsToAttrs(n.props);
  return `${indent}<${tag}${attrs} />`;
}

// ---------------------------------------------------------------------------
// Prop serialisation
// ---------------------------------------------------------------------------

function propsToAttrs(props: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const [key, val] of Object.entries(props)) {
    const attr = serializeAttr(key, val);
    if (attr !== null) parts.push(attr);
  }
  return parts.length > 0 ? " " + parts.join(" ") : "";
}

function serializeAttr(key: string, val: unknown): string | null {
  if (val === undefined || val === null) return null;
  if (typeof val === "boolean") {
    return val ? key : null;         // true → shorthand, false → omit
  }
  if (typeof val === "number") {
    return `${key}={${val}}`;
  }
  if (typeof val === "string") {
    return `${key}="${val}"`;
  }
  if (Array.isArray(val)) {
    const items = val.map((v) => (typeof v === "string" ? `"${v}"` : String(v))).join(", ");
    return `${key}={[${items}]}`;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

function pascal(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

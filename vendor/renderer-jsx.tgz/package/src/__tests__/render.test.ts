/**
 * IR → JSX source string renderer tests.
 *
 * These tests work directly with IRDocument — no DSL builders.
 * That isolates this layer from compile() and lets us verify
 * the exact JSX output format independently.
 *
 * Output format conventions:
 *   - Component names: PascalCase matching dslType
 *   - String props:  label="value"
 *   - Number props:  gap={8}
 *   - Boolean true:  required  (shorthand, no ={true})
 *   - Arrays:        columns={["A", "B"]}
 *   - Text children: <Button>OK</Button>  (nodes with a natural text body)
 *   - Self-closing:  <Stat label="Revenue" value={42} />  (data nodes)
 *   - Indentation:   2 spaces per nesting level
 *   - Document root: <Page title="...">...</Page>
 */
import { describe, it, expect } from "vitest";
import type { IRContainerNode, IRDocument, IRLeafNode } from "@openmockup/renderer-core";
import { jsxRenderer } from "@openmockup/renderer-jsx";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function doc(root: IRLeafNode | IRContainerNode, title = "t"): IRDocument {
  return { version: "0.1", title, root };
}

function leaf(dslType: string, props: Record<string, unknown> = {}): IRLeafNode {
  return { kind: "leaf", dslType, props };
}

function container(
  dslType: string,
  children: (IRLeafNode | IRContainerNode)[],
  props: Record<string, unknown> = {},
): IRContainerNode {
  return { kind: "container", dslType, children, props };
}

function render(root: IRLeafNode | IRContainerNode, title = "t"): string {
  return jsxRenderer.render(doc(root, title), jsxRenderer.target);
}

// ---------------------------------------------------------------------------
// Document wrapper
// ---------------------------------------------------------------------------

describe("Page wrapper", () => {
  it("wraps output in <Page title>", () => {
    const out = jsxRenderer.render(doc(leaf("label", { text: "Hi" }), "My page"), jsxRenderer.target);
    expect(out).toMatch(/^<Page title="My page">/);
    expect(out).toMatch(/<\/Page>$/);
  });
});

// ---------------------------------------------------------------------------
// Leaf nodes with text children
// ---------------------------------------------------------------------------

describe("button", () => {
  it("renders label as children, variant as prop", () => {
    expect(render(leaf("button", { label: "OK", variant: "primary" }))).toContain(
      '<Button variant="primary">OK</Button>',
    );
  });

  it("secondary variant", () => {
    expect(render(leaf("button", { label: "Cancel", variant: "secondary" }))).toContain(
      '<Button variant="secondary">Cancel</Button>',
    );
  });
});

describe("label", () => {
  it("renders text as children", () => {
    expect(render(leaf("label", { text: "Hello world" }))).toContain("<Label>Hello world</Label>");
  });
});

describe("heading", () => {
  it("renders text as children with level prop", () => {
    expect(render(leaf("heading", { text: "Section title", level: 2 }))).toContain(
      '<Heading level={2}>Section title</Heading>',
    );
  });
});

describe("paragraph", () => {
  it("renders text as children", () => {
    expect(render(leaf("paragraph", { text: "Body copy" }))).toContain(
      "<Paragraph>Body copy</Paragraph>",
    );
  });
});

describe("badge", () => {
  it("renders text as children", () => {
    expect(render(leaf("badge", { text: "New" }))).toContain("<Badge>New</Badge>");
  });
});

describe("alert", () => {
  it("renders text as children, variant as prop", () => {
    expect(render(leaf("alert", { variant: "warning", text: "Watch out" }))).toContain(
      '<Alert variant="warning">Watch out</Alert>',
    );
  });
});

describe("linkAction", () => {
  it("renders label as children", () => {
    expect(render(leaf("linkAction", { label: "Skip" }))).toContain("<LinkAction>Skip</LinkAction>");
  });
});

// ---------------------------------------------------------------------------
// Leaf nodes — self-closing (no natural text child)
// ---------------------------------------------------------------------------

describe("stat", () => {
  it("self-closing with label and numeric value", () => {
    expect(render(leaf("stat", { label: "Revenue", value: 42 }))).toContain(
      '<Stat label="Revenue" value={42} />',
    );
  });

  it("self-closing with string value", () => {
    expect(render(leaf("stat", { label: "Status", value: "Active" }))).toContain(
      '<Stat label="Status" value="Active" />',
    );
  });
});

describe("progress", () => {
  it("self-closing with numeric value", () => {
    expect(render(leaf("progress", { value: 75 }))).toContain("<Progress value={75} />");
  });
});

describe("pagination", () => {
  it("self-closing with all three props", () => {
    expect(render(leaf("pagination", { page: 1, pageSize: 20, total: 100 }))).toContain(
      "<Pagination page={1} pageSize={20} total={100} />",
    );
  });
});

describe("tabs", () => {
  it("renders tabs array and active index", () => {
    expect(render(leaf("tabs", { tabs: ["All", "This month", "At risk"], active: 0 }))).toContain(
      '<Tabs tabs={["All", "This month", "At risk"]} active={0} />',
    );
  });
});

describe("table", () => {
  it("renders dataSource and columns array", () => {
    expect(render(leaf("table", { dataSource: "orders", columns: ["ID", "Customer", "Total"] }))).toContain(
      '<Table dataSource="orders" columns={["ID", "Customer", "Total"]} />',
    );
  });
});

describe("image", () => {
  it("renders aspectRatio when label absent", () => {
    expect(render(leaf("image", { aspectRatio: "16:9" }))).toContain('<Image aspectRatio="16:9" />');
  });

  it("renders label prop when present", () => {
    expect(render(leaf("image", { label: "Hero photo", aspectRatio: "4:3" }))).toContain(
      '<Image label="Hero photo" aspectRatio="4:3" />',
    );
  });
});

describe("avatar", () => {
  it("renders name and size", () => {
    expect(render(leaf("avatar", { name: "Jane Doe", size: "md" }))).toContain(
      '<Avatar name="Jane Doe" size="md" />',
    );
  });
});

// ---------------------------------------------------------------------------
// Field — boolean shorthand for required
// ---------------------------------------------------------------------------

describe("field", () => {
  it("required=true renders as shorthand boolean attr", () => {
    expect(
      render(leaf("field", { key: "email", component: "textInput", label: "Email", required: true })),
    ).toContain('<Field key="email" component="textInput" label="Email" required />');
  });

  it("required=false omits the attribute", () => {
    const out = render(leaf("field", { key: "bio", component: "textArea", label: "Bio", required: false }));
    expect(out).toContain('<Field key="bio" component="textArea" label="Bio" />');
    expect(out).not.toContain("required");
  });
});

// ---------------------------------------------------------------------------
// Container nodes
// ---------------------------------------------------------------------------

describe("stack", () => {
  it("vertical stack renders children indented inside", () => {
    const out = render(
      container("stack", [leaf("label", { text: "A" }), leaf("label", { text: "B" })], {
        direction: "vertical",
        gap: 8,
      }),
    );
    expect(out).toContain('<Stack direction="vertical" gap={8}>');
    expect(out).toContain("  <Label>A</Label>");
    expect(out).toContain("  <Label>B</Label>");
    expect(out).toContain("</Stack>");
  });

  it("horizontal stack", () => {
    const out = render(
      container("stack", [leaf("button", { label: "OK", variant: "primary" })], {
        direction: "horizontal",
        gap: 4,
      }),
    );
    expect(out).toContain('<Stack direction="horizontal" gap={4}>');
  });
});

describe("section", () => {
  it("renders title prop and children", () => {
    const out = render(
      container("section", [leaf("label", { text: "Body" })], { title: "My Section" }),
    );
    expect(out).toContain('<Section title="My Section">');
    expect(out).toContain("  <Label>Body</Label>");
    expect(out).toContain("</Section>");
  });
});

describe("card", () => {
  it("renders title prop and children", () => {
    const out = render(
      container("card", [leaf("stat", { label: "Value", value: "$48 000" })], { title: "Deal info" }),
    );
    expect(out).toContain('<Card title="Deal info">');
    expect(out).toContain('</Card>');
  });
});

describe("form", () => {
  it("renders field children inside Form", () => {
    const out = render(
      container("form", [
        leaf("field", { key: "name", component: "textInput", label: "Name", required: true }),
        leaf("field", { key: "email", component: "textInput", label: "Email", required: false }),
      ]),
    );
    expect(out).toContain("<Form>");
    expect(out).toContain('<Field key="name" component="textInput" label="Name" required />');
    expect(out).toContain('<Field key="email" component="textInput" label="Email" />');
    expect(out).toContain("</Form>");
  });
});

describe("actionBar", () => {
  it("renders children inside ActionBar", () => {
    const out = render(
      container("actionBar", [
        leaf("button", { label: "Save", variant: "primary" }),
        leaf("linkAction", { label: "Cancel" }),
      ]),
    );
    expect(out).toContain("<ActionBar>");
    expect(out).toContain('<Button variant="primary">Save</Button>');
    expect(out).toContain("<LinkAction>Cancel</LinkAction>");
    expect(out).toContain("</ActionBar>");
  });
});

describe("drawer", () => {
  it("renders side prop", () => {
    const out = render(
      container("drawer", [leaf("label", { text: "Content" })], { side: "right" }),
    );
    expect(out).toContain('<Drawer side="right">');
  });
});

// ---------------------------------------------------------------------------
// Nesting — indentation increases with depth
// ---------------------------------------------------------------------------

describe("nesting", () => {
  it("children of children are indented by 2 extra spaces per level", () => {
    const out = render(
      container(
        "section",
        [container("stack", [leaf("label", { text: "Deep" })], { direction: "vertical", gap: 8 })],
        { title: "S" },
      ),
    );
    // Section children indented 2 spaces, stack children indented 4 spaces
    expect(out).toContain('  <Stack direction="vertical" gap={8}>');
    expect(out).toContain("    <Label>Deep</Label>");
  });
});

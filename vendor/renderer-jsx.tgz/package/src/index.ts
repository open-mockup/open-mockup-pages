import type { IRDocument, Renderer } from "@openmockup/renderer-core";
import { renderJsx } from "./render.js";

export interface JsxTarget {
  readonly id: "jsx";
}

export const jsxRenderer: Renderer<JsxTarget, string> = {
  target: { id: "jsx" },
  render(ir: IRDocument): string {
    return renderJsx(ir);
  },
};

# @openmockup/renderer-jsx

## 0.1.2

### Patch Changes

- change organization to openmockup
- Updated dependencies
  - @openmockup/renderer-core@0.1.2

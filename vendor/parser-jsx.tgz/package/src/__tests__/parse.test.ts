/**
 * JSX source string → IRDocument parser tests.
 *
 * These tests verify the mapping contract defined in ADR-010:
 *   - Tag name → dslType (PascalCase → camelCase)
 *   - String attr   label="OK"          → props.label = "OK"
 *   - Number attr   gap={8}             → props.gap = 8
 *   - Boolean attr  required            → props.required = true
 *   - Array expr    columns={["A","B"]} → props.columns = ["A", "B"]
 *   - JSX children  → children[] (container node)
 *   - Self-closing  → leaf node
 *   - Root element  <Page title="T">   → ir.title = "T", ir.root
 */
import { describe, it, expect } from "vitest";
import type { IRContainerNode, IRLeafNode } from "@openmockup/renderer-core";
import { parseJsx } from "@openmockup/parser-jsx";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parse(jsx: string) {
  return parseJsx(jsx);
}

function leaf(ir: ReturnType<typeof parse>["root"]): IRLeafNode {
  expect(ir.kind).toBe("leaf");
  return ir as IRLeafNode;
}

function container(ir: ReturnType<typeof parse>["root"]): IRContainerNode {
  expect(ir.kind).toBe("container");
  return ir as IRContainerNode;
}

// ---------------------------------------------------------------------------
// Document root
// ---------------------------------------------------------------------------

describe("Page wrapper", () => {
  it("produces IRDocument with version 0.1", () => {
    const ir = parse(`<Page title="Dashboard" />`);
    expect(ir.version).toBe("0.1");
  });

  it("extracts title from Page tag", () => {
    const ir = parse(`<Page title="My Page" />`);
    expect(ir.title).toBe("My Page");
  });

  it("root dslType is 'page'", () => {
    const ir = parse(`<Page title="T" />`);
    expect(ir.root.dslType).toBe("page");
  });

  it("page with children is a container node", () => {
    const ir = parse(`<Page title="T"><Label text="Hi" /></Page>`);
    expect(ir.root.kind).toBe("container");
  });

  it("self-closing page is a leaf node", () => {
    const ir = parse(`<Page title="T" />`);
    expect(ir.root.kind).toBe("leaf");
  });
});

// ---------------------------------------------------------------------------
// Tag name → dslType (PascalCase → camelCase)
// ---------------------------------------------------------------------------

describe("tag name → dslType", () => {
  it("Button → button", () => {
    const ir = parse(`<Page title="t"><Button label="OK" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].dslType).toBe("button");
  });

  it("ActionBar → actionBar", () => {
    const ir = parse(`<Page title="t"><ActionBar /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].dslType).toBe("actionBar");
  });

  it("LinkAction → linkAction", () => {
    const ir = parse(`<Page title="t"><LinkAction label="Skip" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].dslType).toBe("linkAction");
  });

  it("EmptyState → emptyState", () => {
    const ir = parse(`<Page title="t"><EmptyState title="None" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].dslType).toBe("emptyState");
  });
});

// ---------------------------------------------------------------------------
// Prop types
// ---------------------------------------------------------------------------

describe("string prop", () => {
  it("label='OK' → props.label = 'OK'", () => {
    const ir = parse(`<Page title="t"><Button label="OK" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.label).toBe("OK");
  });

  it("variant='primary' is preserved", () => {
    const ir = parse(`<Page title="t"><Button label="Save" variant="primary" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.variant).toBe("primary");
  });
});

describe("number prop", () => {
  it("gap={8} → props.gap = 8", () => {
    const ir = parse(`<Page title="t"><Stack gap={8} /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.gap).toBe(8);
  });

  it("level={2} → props.level = 2", () => {
    const ir = parse(`<Page title="t"><Heading level={2} text="Title" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.level).toBe(2);
  });
});

describe("boolean prop", () => {
  it("required shorthand → props.required = true", () => {
    const ir = parse(`<Page title="t"><Field name="x" required /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.required).toBe(true);
  });

  it("required={false} → props.required = false", () => {
    const ir = parse(`<Page title="t"><Field name="x" required={false} /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.required).toBe(false);
  });
});

describe("array prop", () => {
  it('columns={["ID","Name"]} → props.columns = ["ID","Name"]', () => {
    const ir = parse(`<Page title="t"><Table columns={["ID", "Name"]} /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.columns).toEqual(["ID", "Name"]);
  });

  it("tabs array with multiple items", () => {
    const ir = parse(`<Page title="t"><Tabs tabs={["All", "Active", "Closed"]} active={0} /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].props.tabs).toEqual(["All", "Active", "Closed"]);
    expect(c.children[0].props.active).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// Leaf vs container
// ---------------------------------------------------------------------------

describe("leaf node (self-closing, no JSX children)", () => {
  it("self-closing tag is a leaf", () => {
    const ir = parse(`<Page title="t"><Label text="Hi" /></Page>`);
    const c = container(ir.root);
    expect(c.children[0].kind).toBe("leaf");
  });

  it("leaf has no children property meaningfully (empty or absent)", () => {
    const ir = parse(`<Page title="t"><Stat label="Rev" value={42} /></Page>`);
    const c = container(ir.root);
    const node = c.children[0] as IRLeafNode;
    expect(node.kind).toBe("leaf");
  });
});

describe("container node (has JSX children)", () => {
  it("tag with children is a container", () => {
    const ir = parse(`<Page title="t"><Stack><Label text="A" /></Stack></Page>`);
    const c = container(ir.root);
    expect(c.children[0].kind).toBe("container");
  });

  it("children are parsed recursively", () => {
    const ir = parse(`<Page title="t"><Stack><Label text="A" /><Label text="B" /></Stack></Page>`);
    const c = container(ir.root);
    const stack = container(c.children[0]);
    expect(stack.children).toHaveLength(2);
    expect(stack.children[0].dslType).toBe("label");
    expect(stack.children[1].dslType).toBe("label");
  });

  it("props on container node are preserved", () => {
    const ir = parse(`<Page title="t"><Stack direction="vertical" gap={8}><Label text="A" /></Stack></Page>`);
    const c = container(ir.root);
    const stack = c.children[0];
    expect(stack.props.direction).toBe("vertical");
    expect(stack.props.gap).toBe(8);
  });
});

// ---------------------------------------------------------------------------
// Nesting
// ---------------------------------------------------------------------------

describe("deep nesting", () => {
  it("three levels deep", () => {
    const ir = parse(
      `<Page title="t"><Section title="S"><Stack gap={4}><Label text="Deep" /></Stack></Section></Page>`,
    );
    const c = container(ir.root);
    const section = container(c.children[0]);
    const stack = container(section.children[0]);
    expect(stack.children[0].dslType).toBe("label");
    expect(stack.children[0].props.text).toBe("Deep");
  });
});

// ---------------------------------------------------------------------------
// Realistic screens
// ---------------------------------------------------------------------------

describe("form screen", () => {
  it("parses a form with two fields", () => {
    const ir = parse(`
      <Page title="New Order">
        <Form>
          <Field name="customer" label="Customer" component="textInput" required />
          <Field name="amount"   label="Amount"   component="textInput" />
        </Form>
        <ActionBar>
          <Button label="Save" variant="primary" />
          <LinkAction label="Cancel" />
        </ActionBar>
      </Page>
    `);
    expect(ir.title).toBe("New Order");
    const root = container(ir.root);
    expect(root.children).toHaveLength(2);

    const form = container(root.children[0]);
    expect(form.dslType).toBe("form");
    expect(form.children).toHaveLength(2);
    expect(form.children[0].props.required).toBe(true);
    expect(form.children[1].props.required).toBeUndefined();

    const actionBar = container(root.children[1]);
    expect(actionBar.dslType).toBe("actionBar");
    expect(actionBar.children).toHaveLength(2);
  });
});

describe("table screen", () => {
  it("parses simple table with columns and rows props", () => {
    const ir = parse(`
      <Page title="Orders">
        <Table
          columns="ID / Customer / Total"
          rows="1 / John Doe / $100\n2 / Jane / $50"
        />
      </Page>
    `);
    const root = container(ir.root);
    const table = leaf(root.children[0]);
    expect(table.dslType).toBe("table");
    expect(table.props.columns).toBe("ID / Customer / Total");
    expect(table.props.rows).toBe("1 / John Doe / $100\n2 / Jane / $50");
  });

  it("parses table with Column children", () => {
    const ir = parse(`
      <Page title="Users">
        <Table rows="John / Active\nJane / Inactive">
          <Column header="Name" />
          <Column header="Status" />
          <Column header="Actions">
            <Button label="Edit" variant="secondary" />
          </Column>
        </Table>
      </Page>
    `);
    const root = container(ir.root);
    const table = container(root.children[0]);
    expect(table.dslType).toBe("table");
    expect(table.props.rows).toBe("John / Active\nJane / Inactive");
    expect(table.children).toHaveLength(3);

    expect(table.children[0].kind).toBe("leaf");
    expect(table.children[0].dslType).toBe("column");

    const actionsCol = container(table.children[2]);
    expect(actionsCol.dslType).toBe("column");
    expect(actionsCol.children[0].dslType).toBe("button");
  });
});

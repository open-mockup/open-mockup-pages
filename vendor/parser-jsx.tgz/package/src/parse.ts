import * as acorn from "acorn";
import acornJsx from "acorn-jsx";
import type { IRDocument, IRNode, IRContainerNode, IRLeafNode } from "@openmockup/renderer-core";

const parser = acorn.Parser.extend(acornJsx());

// Minimal JSX AST node — acorn-jsx doesn't ship types, so we use a loose shape.
type AcornNode = Record<string, unknown>;

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export function parseJsx(source: string): IRDocument {
  const ast = parser.parse(source.trim(), {
    ecmaVersion: 2020,
    sourceType: "module",
  }) as unknown as AcornNode;

  const body = ast["body"] as AcornNode[];
  const expr = body[0];
  if (!expr || expr["type"] !== "ExpressionStatement") {
    throw new Error("JSX source must be a single root JSX element");
  }

  const root = expr["expression"] as AcornNode;
  if (!isJsxElement(root) && !isJsxSelfClosing(root)) {
    throw new Error("Root expression must be a JSX element");
  }

  const title = getStringAttr(root, "title") ?? "";
  const rootNode = buildNode(root);

  return { version: "0.1", title, root: rootNode };
}

// ---------------------------------------------------------------------------
// AST node → IRNode
// ---------------------------------------------------------------------------

function buildNode(el: AcornNode): IRNode {
  const dslType = camel(getTagName(el));
  const props = buildProps(el);
  const jsxChildren = getJsxChildren(el);

  if (jsxChildren.length === 0) {
    return { kind: "leaf", dslType, props } satisfies IRLeafNode;
  }

  const children = jsxChildren.map(buildNode);
  return { kind: "container", dslType, props, children } satisfies IRContainerNode;
}

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

function buildProps(el: AcornNode): Record<string, unknown> {
  const opening = el["openingElement"] as AcornNode | undefined;
  const attrs = ((opening ?? el)["attributes"] as AcornNode[] | undefined) ?? [];
  const props: Record<string, unknown> = {};

  for (const attr of attrs) {
    if (attr["type"] !== "JSXAttribute") continue;
    const key = getAttrName(attr);
    props[key] = getAttrValue(attr);
  }

  return props;
}

function getAttrName(attr: AcornNode): string {
  const name = attr["name"] as AcornNode;
  return name["name"] as string;
}

function getAttrValue(attr: AcornNode): unknown {
  const val = attr["value"] as AcornNode | null | undefined;

  // Shorthand boolean: <Field required />
  if (val === null || val === undefined) return true;

  // String literal: label="OK"
  if (val["type"] === "Literal") return val["value"];

  // Expression: gap={8}, required={false}, columns={["A","B"]}
  if (val["type"] === "JSXExpressionContainer") {
    return evalExpr(val["expression"] as AcornNode);
  }

  return null;
}

function evalExpr(expr: AcornNode): unknown {
  if (expr["type"] === "Literal") return expr["value"];
  if (expr["type"] === "ArrayExpression") {
    return (expr["elements"] as AcornNode[]).map((e) => evalExpr(e));
  }
  return null;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getTagName(el: AcornNode): string {
  const opening = (el["openingElement"] ?? el) as AcornNode;
  const name = opening["name"] as AcornNode;
  return name["name"] as string;
}

function getStringAttr(el: AcornNode, attrName: string): string | undefined {
  const opening = el["openingElement"] as AcornNode | undefined;
  const attrs = ((opening ?? el)["attributes"] as AcornNode[] | undefined) ?? [];

  for (const attr of attrs) {
    if (attr["type"] === "JSXAttribute" && getAttrName(attr) === attrName) {
      const val = attr["value"] as AcornNode | null | undefined;
      if (val?.["type"] === "Literal" && typeof val["value"] === "string") return val["value"];
    }
  }
  return undefined;
}

function getJsxChildren(el: AcornNode): AcornNode[] {
  const children = (el["children"] as AcornNode[] | undefined) ?? [];
  return children.filter((c) => isJsxElement(c) || isJsxSelfClosing(c));
}

function isJsxElement(n: AcornNode): boolean {
  return n["type"] === "JSXElement";
}

function isJsxSelfClosing(n: AcornNode): boolean {
  return n["type"] === "JSXOpeningElement" && (n["selfClosing"] as boolean);
}

// PascalCase → camelCase: "ActionBar" → "actionBar"
function camel(s: string): string {
  return s.charAt(0).toLowerCase() + s.slice(1);
}
